import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Friends extends StatefulWidget {
  @override
  _FriendsState createState() => _FriendsState();
}

class _FriendsState extends State<Friends> {
  String name = 'friends';



  @override
  Widget build(BuildContext context) {
    test();
    return SafeArea(
      child: Text(name),
    );
  }

  void test() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    await sharedPreferences.setString('key', 'value');
    String a=await sharedPreferences.getString('key');

    setState(() {
      name=a;
    });

  }
}
