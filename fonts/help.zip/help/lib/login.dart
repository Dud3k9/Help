import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:simple_animations/simple_animations/controlled_animation.dart';
import 'package:simple_animations/simple_animations/multi_track_tween.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {

  @override
  void initState() {

    final FirebaseAuth _auth = FirebaseAuth.instance;
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: AnimatedBackground(
          child: Padding(
            padding: EdgeInsets.all(40),
            child: Column(
              children: <Widget>[
                SizedBox(height: 40,),
                Text('TODO LOGO AND NAME',style: TextStyle(fontSize: 20,color: Colors.white),),
                SizedBox(height: 60,),
                Text('Login In',style: TextStyle(fontSize: 35,color: Colors.white,letterSpacing: 2),),
                SizedBox(height: 150,),
                SignInButton(
                  Buttons.Google,
                  onPressed: (){},
                  padding: EdgeInsets.symmetric(horizontal: 25,vertical: 5),
                ),
                SizedBox(height: 10,),
                SignInButton(
                  Buttons.Facebook,
                  onPressed: (){},
                  padding: EdgeInsets.symmetric(horizontal: 25,vertical: 15),
                )
              ],
            )
          ),
        ),
      ),
    );
  }
}

class AnimatedBackground extends StatelessWidget {
  Widget child;

  AnimatedBackground({this.child});

  @override
  Widget build(BuildContext context) {
    final tween = MultiTrackTween([
      Track("color1").add(Duration(seconds: 5),
          ColorTween(begin: Colors.orange[900], end: Colors.orange[700])),
      Track("color2").add(Duration(seconds: 3),
          ColorTween(begin: Colors.orange[600], end: Colors.orange[300]))
    ]);

    return ControlledAnimation(
      playback: Playback.MIRROR,
      tween: tween,
      duration: tween.duration,
      builder: (context, animation) {
        return Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  end: Alignment.topLeft,
                  begin: Alignment.bottomRight,
                  colors: [animation["color1"], animation["color2"]])),
          child: child,
        );
      },
    );
  }
}
