import 'package:flutter/material.dart';
import 'package:help/NavigationBar.dart';
import 'package:help/login.dart';
import 'package:help/settings.dart';
import 'package:help/alarm.dart';
import 'package:help/friends.dart';

class MainScrean extends StatefulWidget {
  @override
  _MainScreanState createState() => _MainScreanState();
}

class _MainScreanState extends State<MainScrean> {

@override
  void initState() {
    super.initState();
    HomeState.state=this;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: MyBottomNavigationBar(),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, colors: [
          Colors.orange[900],
          Colors.orange[800],
          Colors.orange[500]
        ])),
        child: HomeState.children[HomeState.selected],
      ),
    );
  }
}

class HomeState{
  static final List<Widget> children = [
    Alarm(),
    Friends(),
    Settings(),
  ];

  static State state;
  static int selected=0;
}